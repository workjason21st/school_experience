package edu.tku.web.controller.system;

import edu.tku.db.model.User;
import edu.tku.db.repository.UserRepository;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class UserController {
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/user")
    public String page(Model model, @RequestParam(name = "userId", required = false) String userId) {
        List<User> users = new ArrayList<>();
        if(userId != null && !userId.equals("")) {
            userRepository.findById(userId).ifPresent(user -> users.add(user));
        }else{
            users.addAll(userRepository.findAll());
        }
        model.addAttribute("users", users);
        return "system/user";
    }
    @GetMapping("/user/detail")
    public String pageDetail(Model model, @RequestParam(name = "userId", required = false) String userId) {
        User user = userRepository.findById(StringUtils.defaultString(userId, "")).orElse(new User());
        model.addAttribute("user", user);
        return "system/userDetail";
    }
    @PostMapping("/user")
    public String pageDetail(Model model, @ModelAttribute User user) {
        if(user.getAction().equals("D")) {
            userRepository.deleteById(user.getUserId());
        }else {
            if(user.getEmail() == null){
                user.setEmail(" ");
            }
            user.setBranchId("[]");
            user.setDepId("[]");
            user.setToken("[]");
            userRepository.save(user);
        }
        model.addAttribute("users", userRepository.findAll());
        return "system/user";
    }

}
